#导入包
from hyperlpr import *
#导入OpenCV库
import cv2
#读入图片
image = cv2.imread("test2.jpg")
#识别结果
res_set,image = HyperLPR_plate_recognition(image)
print(res_set)

print(image)
cv2.imshow("wo",image)
cv2.waitKey(0)
